# Personal Page In Class CSS Assignment 

A Pen created on CodePen.

Original URL: [https://codepen.io/Hosna-Zainab-Afssari/pen/WbNgwOw](https://codepen.io/Hosna-Zainab-Afssari/pen/WbNgwOw).

